# The Tribute Page 

# 🔴 Live Server
https://apjtributewebpage.netlify.app/

# 🔴 Alternate Server
https://multiprocessing-muggles.github.io/The-Tribute-Website/

![image](https://user-images.githubusercontent.com/66564001/162982274-1a859a15-4f60-4f10-98bd-81038d8a8579.png)



![image](https://user-images.githubusercontent.com/66564001/162982107-97827838-119b-42f9-88ff-e589915c7c51.png)

